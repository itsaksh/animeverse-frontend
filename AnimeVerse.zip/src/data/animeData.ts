export interface Anime {
  id: string;
  title: string;
  synopsis: string;
  genres: string[];
  episodes: number;
  releaseYear: number;
  rating: number;
  image: string;
  characters: Character[];
  similarAnime: string[];
  status: 'Completed' | 'Ongoing' | 'Upcoming';
}

export interface Character {
  id: string;
  name: string;
  image: string;
  role: 'Main' | 'Supporting';
}

// Mock anime data for demonstration
export const mockAnimeData: Anime[] = [
  {
    id: '1',
    title: 'Attack on Titan',
    synopsis: 'Humanity fights for survival against giant humanoid Titans. In a world where humanity lives within enormous walled cities due to the Titans, mysterious giant humanoids that devour humans seemingly without reason, the story follows Eren Yeager, his adopted sister Mikasa Ackerman, and childhood friend Armin Arlert, who join the military to fight the Titans after their hometown is invaded and Eren\'s mother is eaten.',
    genres: ['Action', 'Drama', 'Fantasy', 'Military'],
    episodes: 75,
    releaseYear: 2013,
    rating: 9.0,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '1', name: 'Eren Yeager', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '2', name: 'Mikasa Ackerman', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '3', name: 'Armin Arlert', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '4', name: 'Levi Ackerman', image: '/api/placeholder/100/120', role: 'Supporting' }
    ],
    similarAnime: ['2', '3', '4'],
    status: 'Completed'
  },
  {
    id: '2',
    title: 'Demon Slayer',
    synopsis: 'A young boy becomes a demon slayer to save his sister. Tanjiro Kamado lives with his family in the mountains. When he returns from selling charcoal in town, he discovers that his family has been slaughtered by demons, with only his sister Nezuko surviving - but she has been transformed into a demon.',
    genres: ['Action', 'Historical', 'Supernatural'],
    episodes: 44,
    releaseYear: 2019,
    rating: 8.7,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '5', name: 'Tanjiro Kamado', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '6', name: 'Nezuko Kamado', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '7', name: 'Zenitsu Agatsuma', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '8', name: 'Inosuke Hashibira', image: '/api/placeholder/100/120', role: 'Main' }
    ],
    similarAnime: ['1', '3', '5'],
    status: 'Ongoing'
  },
  {
    id: '3',
    title: 'One Piece',
    synopsis: 'A young pirate searches for the ultimate treasure. Monkey D. Luffy explores the Grand Line with his diverse crew of pirates, named the Straw Hat Pirates, to find the world\'s ultimate treasure known as the "One Piece" in order to become the next Pirate King.',
    genres: ['Action', 'Adventure', 'Comedy', 'Shounen'],
    episodes: 1000,
    releaseYear: 1999,
    rating: 9.5,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '9', name: 'Monkey D. Luffy', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '10', name: 'Roronoa Zoro', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '11', name: 'Nami', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '12', name: 'Sanji', image: '/api/placeholder/100/120', role: 'Main' }
    ],
    similarAnime: ['4', '5', '6'],
    status: 'Ongoing'
  },
  {
    id: '4',
    title: 'Naruto',
    synopsis: 'A young ninja seeks recognition and dreams of becoming Hokage. Naruto Uzumaki is a hyperactive and knuckle-headed ninja living in the Hidden Leaf Village. Ever since he was born, the nine-tailed fox spirit has been sealed within his body, making him the object of fear and disgust in his village.',
    genres: ['Action', 'Adventure', 'Martial Arts', 'Shounen'],
    episodes: 720,
    releaseYear: 2002,
    rating: 8.4,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '13', name: 'Naruto Uzumaki', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '14', name: 'Sasuke Uchiha', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '15', name: 'Sakura Haruno', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '16', name: 'Kakashi Hatake', image: '/api/placeholder/100/120', role: 'Supporting' }
    ],
    similarAnime: ['3', '5', '1'],
    status: 'Completed'
  },
  {
    id: '5',
    title: 'My Hero Academia',
    synopsis: 'In a world where superpowers are the norm, a powerless boy dreams of becoming a hero. In a world where eighty percent of the population has some kind of super-powered Quirk, Izuku was unlucky enough to be born completely normal. But that won\'t stop him from enrolling in a prestigious hero academy.',
    genres: ['Action', 'School', 'Shounen', 'Super Power'],
    episodes: 138,
    releaseYear: 2016,
    rating: 8.6,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '17', name: 'Izuku Midoriya', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '18', name: 'Katsuki Bakugo', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '19', name: 'Ochaco Uraraka', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '20', name: 'Shoto Todoroki', image: '/api/placeholder/100/120', role: 'Main' }
    ],
    similarAnime: ['4', '6', '2'],
    status: 'Ongoing'
  },
  {
    id: '6',
    title: 'Dragon Ball Z',
    synopsis: 'Earth\'s greatest warriors defend the planet from cosmic threats. Five years after the end of Dragon Ball, with the arrival of his son, Gohan, Goku learns that he is a member of a near-extinct warrior race called the Saiyans.',
    genres: ['Action', 'Adventure', 'Martial Arts', 'Shounen'],
    episodes: 291,
    releaseYear: 1989,
    rating: 8.8,
    image: '/api/placeholder/300/400',
    characters: [
      { id: '21', name: 'Goku', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '22', name: 'Vegeta', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '23', name: 'Gohan', image: '/api/placeholder/100/120', role: 'Main' },
      { id: '24', name: 'Piccolo', image: '/api/placeholder/100/120', role: 'Supporting' }
    ],
    similarAnime: ['3', '4', '5'],
    status: 'Completed'
  }
];

// Search function
export const searchAnime = (query: string): Anime[] => {
  if (!query.trim()) return mockAnimeData.slice(0, 6);
  
  const lowercaseQuery = query.toLowerCase();
  return mockAnimeData.filter(anime => 
    anime.title.toLowerCase().includes(lowercaseQuery) ||
    anime.genres.some(genre => genre.toLowerCase().includes(lowercaseQuery)) ||
    anime.synopsis.toLowerCase().includes(lowercaseQuery)
  );
};

// Get anime by ID
export const getAnimeById = (id: string): Anime | undefined => {
  return mockAnimeData.find(anime => anime.id === id);
};

// Get similar anime
export const getSimilarAnime = (animeId: string): Anime[] => {
  const anime = getAnimeById(animeId);
  if (!anime) return [];
  
  return anime.similarAnime
    .map(id => getAnimeById(id))
    .filter((anime): anime is Anime => anime !== undefined);
};

// Get popular anime (top 6)
export const getPopularAnime = (): Anime[] => {
  return [...mockAnimeData]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 6);
};