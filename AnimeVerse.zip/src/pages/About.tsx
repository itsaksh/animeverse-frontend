import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { Search, BookOpen, Users, Zap, Heart, Star } from 'lucide-react';

const About: React.FC = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Search,
      title: 'Instant Search',
      description: 'Find any anime instantly with our powerful search engine and intelligent auto-suggestions.',
      color: 'text-neon-cyan'
    },
    {
      icon: BookOpen,
      title: 'Detailed Stories',
      description: 'Get comprehensive summaries, plot insights, and detailed information for every anime.',
      color: 'text-neon-purple'
    },
    {
      icon: Users,
      title: 'Character Profiles',
      description: 'Explore detailed character information and discover the personalities behind your favorite anime.',
      color: 'text-neon-pink'
    },
    {
      icon: Zap,
      title: 'Fast & Responsive',
      description: 'Lightning-fast performance with a beautiful, mobile-responsive design that works everywhere.',
      color: 'text-neon-blue'
    },
    {
      icon: Heart,
      title: 'Curated Content',
      description: 'Hand-picked anime recommendations and carefully curated content for the best experience.',
      color: 'text-neon-pink'
    },
    {
      icon: Star,
      title: 'Community Driven',
      description: 'Built for anime fans, by anime fans. Join our growing community of anime enthusiasts.',
      color: 'text-neon-cyan'
    }
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="font-anime font-bold text-4xl md:text-6xl mb-6">
            <span className="text-neon-purple">About</span>{' '}
            <span className="text-neon-cyan">AnimeVerse</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Your ultimate destination for discovering anime stories, characters, and worlds. 
            We help you explore the vast universe of anime with instant search and detailed information.
          </p>
        </div>

        {/* Mission Statement */}
        <Card className="bg-gradient-card border-neon-purple/30 shadow-deep mb-16">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl font-anime text-neon-purple">Our Mission</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-lg text-foreground leading-relaxed max-w-4xl mx-auto">
              AnimeVerse was created to bridge the gap between anime curiosity and anime knowledge. 
              Whether you're a seasoned otaku or just starting your anime journey, we provide instant access 
              to comprehensive anime information, helping you discover your next favorite series and dive 
              deeper into the stories that captivate millions worldwide.
            </p>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="mb-16">
          <h2 className="font-anime font-bold text-3xl md:text-4xl text-center mb-12">
            <span className="text-neon-pink">What Makes Us</span>{' '}
            <span className="text-neon-purple">Special</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index}
                  className="bg-gradient-card border-border hover:border-neon-purple/50 transition-all duration-300 hover:glow-neon shadow-deep group"
                >
                  <CardHeader className="text-center pb-4">
                    <div className={`w-12 h-12 rounded-lg mx-auto mb-4 flex items-center justify-center bg-gradient-neon`}>
                      <Icon className="w-6 h-6 text-background" />
                    </div>
                    <CardTitle className={`text-xl font-display ${feature.color} group-hover:animate-glow`}>
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Technology Stack */}
        <Card className="bg-gradient-card border-neon-cyan/30 shadow-deep mb-16">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-anime text-neon-cyan">Built With Love & Technology</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-muted-foreground mb-6">
              AnimeVerse is built using modern web technologies to ensure fast, reliable, and beautiful user experience.
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {['React', 'TypeScript', 'Tailwind CSS', 'Vite', 'Lucide Icons'].map((tech) => (
                <Badge 
                  key={tech} 
                  variant="outline" 
                  className="border-neon-cyan/50 text-neon-cyan hover:border-neon-cyan hover:glow-cyan transition-all duration-300"
                >
                  {tech}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="bg-gradient-card border-neon-purple/30 text-center shadow-deep">
            <CardContent className="p-8">
              <div className="text-4xl font-anime font-bold text-neon-purple mb-2">1000+</div>
              <p className="text-muted-foreground">Anime Titles</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-card border-neon-cyan/30 text-center shadow-deep">
            <CardContent className="p-8">
              <div className="text-4xl font-anime font-bold text-neon-cyan mb-2">10K+</div>
              <p className="text-muted-foreground">Character Profiles</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-card border-neon-pink/30 text-center shadow-deep">
            <CardContent className="p-8">
              <div className="text-4xl font-anime font-bold text-neon-pink mb-2">∞</div>
              <p className="text-muted-foreground">Anime Adventures</p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="bg-gradient-neon text-background text-center shadow-deep">
          <CardContent className="p-12">
            <h2 className="font-anime font-bold text-3xl md:text-4xl mb-4">
              Ready to Explore?
            </h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Join thousands of anime fans who use AnimeVerse to discover their next favorite series. 
              Start your journey into the world of anime today!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/')}
                className="bg-transparent border-2 border-background text-background hover:bg-background hover:text-foreground font-semibold"
              >
                Explore Anime
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/search')}
                className="bg-transparent border-2 border-background text-background hover:bg-background hover:text-foreground font-semibold"
              >
                Start Searching
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default About;