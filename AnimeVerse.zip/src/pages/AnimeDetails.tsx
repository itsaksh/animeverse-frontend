import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, Calendar, Tv, Users, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AnimeCard } from '@/components/anime-card';
import { getAnimeById, getSimilarAnime } from '@/data/animeData';

const AnimeDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const anime = id ? getAnimeById(id) : null;
  const similarAnime = id ? getSimilarAnime(id) : [];

  if (!anime) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="text-6xl mb-4">😕</div>
          <h1 className="text-2xl font-display font-semibold mb-4 text-muted-foreground">
            Anime not found
          </h1>
          <Button variant="hero" onClick={() => navigate('/')}>
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  const handleAnimeClick = (animeId: string) => {
    navigate(`/anime/${animeId}`);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Back Button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="mb-6 text-muted-foreground hover:text-neon-cyan"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Anime Poster */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="overflow-hidden bg-gradient-card border-neon-purple/30 shadow-deep">
                <img
                  src={anime.image}
                  alt={anime.title}
                  className="w-full h-auto object-cover"
                />
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="bg-background/80">
                        <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                        {anime.rating}/10
                      </Badge>
                      <Badge 
                        variant={anime.status === 'Completed' ? 'default' : 'outline'}
                        className={anime.status === 'Ongoing' ? 'border-neon-cyan text-neon-cyan' : ''}
                      >
                        {anime.status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>{anime.releaseYear}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Tv className="w-4 h-4" />
                        <span>{anime.episodes} episodes</span>
                      </div>
                    </div>
                    
                    <Button variant="hero" className="w-full" size="lg">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Watch Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Details */}
          <div className="lg:col-span-2 space-y-8">
            {/* Title and Synopsis */}
            <div>
              <h1 className="font-anime font-bold text-4xl md:text-5xl mb-4">
                <span className="text-neon-purple">{anime.title}</span>
              </h1>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {anime.genres.map((genre) => (
                  <Badge 
                    key={genre} 
                    variant="outline" 
                    className="border-neon-cyan/50 text-neon-cyan hover:border-neon-cyan hover:glow-cyan transition-all duration-300"
                  >
                    {genre}
                  </Badge>
                ))}
              </div>
              
              <Card className="bg-gradient-card border-neon-purple/30">
                <CardHeader>
                  <CardTitle className="text-neon-pink">Synopsis</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground leading-relaxed">
                    {anime.synopsis}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Characters */}
            <Card className="bg-gradient-card border-neon-cyan/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-neon-cyan">
                  <Users className="w-5 h-5" />
                  Main Characters
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {anime.characters.map((character) => (
                    <div 
                      key={character.id} 
                      className="text-center p-3 bg-card rounded-lg border border-border hover:border-neon-purple/50 transition-all duration-300"
                    >
                      <img
                        src={character.image}
                        alt={character.name}
                        className="w-16 h-16 rounded-full mx-auto mb-2 object-cover border-2 border-neon-purple/30"
                      />
                      <h4 className="font-medium text-sm text-foreground">{character.name}</h4>
                      <p className="text-xs text-muted-foreground">{character.role}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Similar Anime */}
        {similarAnime.length > 0 && (
          <section className="py-8">
            <h2 className="font-anime font-bold text-3xl mb-8 text-center">
              <span className="text-neon-pink">Similar</span>{' '}
              <span className="text-neon-purple">Anime</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarAnime.map((anime) => (
                <AnimeCard
                  key={anime.id}
                  anime={anime}
                  onClick={() => handleAnimeClick(anime.id)}
                  className="animate-fade-in"
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default AnimeDetails;