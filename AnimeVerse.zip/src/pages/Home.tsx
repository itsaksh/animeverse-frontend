import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchBar } from '@/components/ui/search-bar';
import { AnimeCard } from '@/components/anime-card';
import { Button } from '@/components/ui/button';
import { getPopularAnime, searchAnime } from '@/data/animeData';
import heroBanner from '@/assets/anime-hero-banner.jpg';

const Home: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const popularAnime = getPopularAnime();
  
  const popularTitles = popularAnime.map(anime => anime.title);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleAnimeClick = (animeId: string) => {
    navigate(`/anime/${animeId}`);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    navigate(`/search?q=${encodeURIComponent(suggestion)}`);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroBanner})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background/90" />
        </div>
        
        {/* Hero Content */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="font-anime font-bold text-4xl md:text-6xl lg:text-7xl mb-6">
            <span className="text-neon-purple animate-glow">Discover Your</span>
            <br />
            <span className="text-neon-cyan">Favorite Anime</span>
            <br />
            <span className="text-neon-pink">Stories!</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Type any anime name and explore its story, characters, and more. 
            Dive into endless worlds of adventure and imagination.
          </p>
          
          {/* Search Bar */}
          <div className="mb-8 animate-float">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              onSearch={handleSearch}
              placeholder="Search anime name..."
              suggestions={searchQuery ? popularTitles.filter(title => 
                title.toLowerCase().includes(searchQuery.toLowerCase())
              ) : []}
              onSuggestionClick={handleSuggestionClick}
              className="mx-auto"
            />
          </div>
          
          {/* CTA Button */}
          <Button 
            variant="hero" 
            size="lg"
            onClick={() => navigate('/search')}
            className="animate-glow text-lg px-8 py-3"
          >
            Start Exploring Now!
          </Button>
        </div>
      </section>

      {/* Popular Anime Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-anime font-bold text-3xl md:text-4xl mb-4">
              <span className="text-neon-purple">Popular</span>{' '}
              <span className="text-neon-cyan">Anime</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Discover the most loved anime series that have captivated audiences worldwide
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {popularAnime.map((anime) => (
              <AnimeCard
                key={anime.id}
                anime={anime}
                onClick={() => handleAnimeClick(anime.id)}
                className="animate-fade-in"
              />
            ))}
          </div>
          
          <div className="text-center">
            <Button 
              variant="neon" 
              size="lg"
              onClick={() => navigate('/search')}
            >
              View All Anime
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-gradient-card">
        <div className="container mx-auto text-center">
          <h2 className="font-anime font-bold text-3xl md:text-4xl mb-12">
            <span className="text-neon-pink">Why Choose</span>{' '}
            <span className="text-neon-purple">AnimeVerse?</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-card rounded-lg border border-neon-purple/30 hover:border-neon-purple transition-all duration-300 hover:glow-neon">
              <div className="w-12 h-12 bg-gradient-neon rounded-lg mx-auto mb-4 flex items-center justify-center">
                <span className="text-background font-bold text-xl">⚡</span>
              </div>
              <h3 className="font-display font-semibold text-xl mb-2 text-neon-cyan">
                Instant Search
              </h3>
              <p className="text-muted-foreground">
                Find any anime instantly with our powerful search engine and auto-suggestions.
              </p>
            </div>
            
            <div className="p-6 bg-card rounded-lg border border-neon-cyan/30 hover:border-neon-cyan transition-all duration-300 hover:glow-cyan">
              <div className="w-12 h-12 bg-gradient-neon rounded-lg mx-auto mb-4 flex items-center justify-center">
                <span className="text-background font-bold text-xl">📚</span>
              </div>
              <h3 className="font-display font-semibold text-xl mb-2 text-neon-pink">
                Detailed Stories
              </h3>
              <p className="text-muted-foreground">
                Get comprehensive summaries, character details, and plot insights for every anime.
              </p>
            </div>
            
            <div className="p-6 bg-card rounded-lg border border-neon-pink/30 hover:border-neon-pink transition-all duration-300 hover:glow-pink">
              <div className="w-12 h-12 bg-gradient-neon rounded-lg mx-auto mb-4 flex items-center justify-center">
                <span className="text-background font-bold text-xl">🎯</span>
              </div>
              <h3 className="font-display font-semibold text-xl mb-2 text-neon-purple">
                Smart Recommendations
              </h3>
              <p className="text-muted-foreground">
                Discover new anime based on your preferences and similar series you might love.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;