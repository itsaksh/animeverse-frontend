import React from 'react';
import { Heart, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';

const Favorites: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-anime font-bold text-4xl md:text-5xl mb-6">
            <span className="text-neon-pink">Your</span>{' '}
            <span className="text-neon-purple">Favorites</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Save and organize your favorite anime series for quick access anytime.
          </p>
        </div>

        {/* Empty State */}
        <Card className="bg-gradient-card border-neon-purple/30 shadow-deep max-w-2xl mx-auto">
          <CardContent className="text-center p-12">
            <div className="w-20 h-20 bg-gradient-neon rounded-full mx-auto mb-6 flex items-center justify-center">
              <Heart className="w-10 h-10 text-background" />
            </div>
            
            <h2 className="font-display font-semibold text-2xl mb-4 text-neon-cyan">
              No Favorites Yet
            </h2>
            
            <p className="text-muted-foreground mb-8 leading-relaxed">
              You haven't added any anime to your favorites yet. Start exploring our vast collection 
              and save the anime you love for easy access later.
            </p>
            
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground mb-6">
                <p className="flex items-center justify-center gap-2 mb-2">
                  <BookOpen className="w-4 h-4" />
                  Pro tip: Click the heart icon on any anime to add it to your favorites!
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="hero" 
                  size="lg"
                  onClick={() => navigate('/')}
                >
                  Explore Popular Anime
                </Button>
                <Button 
                  variant="neon" 
                  size="lg"
                  onClick={() => navigate('/search')}
                >
                  Search Anime
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Coming Soon Features */}
        <div className="mt-16 text-center">
          <h3 className="font-display font-semibold text-xl mb-6 text-neon-purple">
            Coming Soon to Favorites
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="p-6 bg-card rounded-lg border border-neon-cyan/30 hover:border-neon-cyan transition-all duration-300">
              <div className="text-3xl mb-3">📱</div>
              <h4 className="font-medium text-neon-cyan mb-2">Sync Across Devices</h4>
              <p className="text-sm text-muted-foreground">
                Access your favorites from any device with cloud synchronization.
              </p>
            </div>
            
            <div className="p-6 bg-card rounded-lg border border-neon-pink/30 hover:border-neon-pink transition-all duration-300">
              <div className="text-3xl mb-3">📝</div>
              <h4 className="font-medium text-neon-pink mb-2">Personal Notes</h4>
              <p className="text-sm text-muted-foreground">
                Add personal notes and ratings to your favorite anime.
              </p>
            </div>
            
            <div className="p-6 bg-card rounded-lg border border-neon-purple/30 hover:border-neon-purple transition-all duration-300">
              <div className="text-3xl mb-3">🎯</div>
              <h4 className="font-medium text-neon-purple mb-2">Smart Lists</h4>
              <p className="text-sm text-muted-foreground">
                Organize favorites into custom lists like "To Watch" or "Completed".
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Favorites;