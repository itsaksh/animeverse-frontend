import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { SearchBar } from '@/components/ui/search-bar';
import { AnimeCard } from '@/components/anime-card';
import { Badge } from '@/components/ui/badge';
import { searchAnime, getPopularAnime, Anime } from '@/data/animeData';

const Search: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [searchResults, setSearchResults] = useState<Anime[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const popularAnime = getPopularAnime();
  const popularTitles = popularAnime.map(anime => anime.title);

  useEffect(() => {
    const query = searchParams.get('q');
    if (query) {
      setSearchQuery(query);
      performSearch(query);
    } else {
      // Show popular anime if no search query
      setSearchResults(popularAnime);
    }
  }, [searchParams]);

  const performSearch = async (query: string) => {
    setIsLoading(true);
    // Simulate API delay for better UX
    setTimeout(() => {
      const results = searchAnime(query);
      setSearchResults(results);
      setIsLoading(false);
    }, 300);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      const params = new URLSearchParams();
      params.set('q', searchQuery.trim());
      navigate(`/search?${params.toString()}`);
    }
  };

  const handleAnimeClick = (animeId: string) => {
    navigate(`/anime/${animeId}`);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    const params = new URLSearchParams();
    params.set('q', suggestion);
    navigate(`/search?${params.toString()}`);
  };

  const currentQuery = searchParams.get('q');

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Search Section */}
        <div className="text-center mb-12">
          <h1 className="font-anime font-bold text-4xl md:text-5xl mb-6">
            <span className="text-neon-purple">Search</span>{' '}
            <span className="text-neon-cyan">Anime</span>
          </h1>
          
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={handleSearch}
            placeholder="Search anime name, genre, or keyword..."
            suggestions={searchQuery ? popularTitles.filter(title => 
              title.toLowerCase().includes(searchQuery.toLowerCase())
            ).slice(0, 5) : []}
            onSuggestionClick={handleSuggestionClick}
            className="max-w-2xl mx-auto"
          />
        </div>

        {/* Results Section */}
        <div className="mb-8">
          {currentQuery ? (
            <div className="flex items-center gap-2 mb-6">
              <h2 className="text-xl font-display font-semibold text-foreground">
                Search results for:
              </h2>
              <Badge variant="outline" className="text-neon-cyan border-neon-cyan/50">
                "{currentQuery}"
              </Badge>
              <span className="text-muted-foreground">
                ({searchResults.length} {searchResults.length === 1 ? 'result' : 'results'})
              </span>
            </div>
          ) : (
            <h2 className="text-2xl font-display font-semibold text-center mb-6">
              <span className="text-neon-pink">Popular</span>{' '}
              <span className="text-neon-purple">Anime</span>
            </h2>
          )}
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-neon-purple"></div>
            <p className="text-muted-foreground mt-4">Searching anime...</p>
          </div>
        )}

        {/* Results Grid */}
        {!isLoading && (
          <>
            {searchResults.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {searchResults.map((anime) => (
                  <AnimeCard
                    key={anime.id}
                    anime={anime}
                    onClick={() => handleAnimeClick(anime.id)}
                    className="animate-fade-in"
                  />
                ))}
              </div>
            ) : currentQuery ? (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-display font-semibold mb-2 text-muted-foreground">
                  No anime found
                </h3>
                <p className="text-muted-foreground mb-6">
                  Try searching with different keywords or check your spelling.
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  <span className="text-sm text-muted-foreground mr-2">Popular searches:</span>
                  {popularTitles.slice(0, 4).map((title) => (
                    <Badge
                      key={title}
                      variant="outline"
                      className="cursor-pointer border-neon-cyan/50 text-neon-cyan hover:border-neon-cyan hover:glow-cyan transition-all duration-300"
                      onClick={() => handleSuggestionClick(title)}
                    >
                      {title}
                    </Badge>
                  ))}
                </div>
              </div>
            ) : null}
          </>
        )}

        {/* Popular Genres */}
        {!currentQuery && !isLoading && (
          <div className="mt-16 text-center">
            <h3 className="text-xl font-display font-semibold mb-6 text-neon-purple">
              Popular Genres
            </h3>
            <div className="flex flex-wrap justify-center gap-2">
              {['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Romance', 'Slice of Life', 'Supernatural'].map((genre) => (
                <Badge
                  key={genre}
                  variant="outline"
                  className="cursor-pointer border-neon-pink/50 text-neon-pink hover:border-neon-pink hover:glow-pink transition-all duration-300"
                  onClick={() => handleSuggestionClick(genre)}
                >
                  {genre}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;