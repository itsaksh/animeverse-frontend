import React from 'react';
import { Search } from 'lucide-react';
import { Input } from './input';
import { Button } from './button';
import { cn } from '@/lib/utils';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onSearch: () => void;
  placeholder?: string;
  className?: string;
  suggestions?: string[];
  onSuggestionClick?: (suggestion: string) => void;
}

export const SearchBar = React.forwardRef<HTMLDivElement, SearchBarProps>(
  ({
    value,
    onChange,
    onSearch,
    placeholder = "Search anime name...",
    className,
    suggestions = [],
    onSuggestionClick,
    ...props
  }, ref) => {
    const [showSuggestions, setShowSuggestions] = React.useState(false);

    const handleKeyPress = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        onSearch();
        setShowSuggestions(false);
      }
    };

    const handleSuggestionClick = (suggestion: string) => {
      onChange(suggestion);
      onSuggestionClick?.(suggestion);
      setShowSuggestions(false);
    };

    return (
      <div ref={ref} className={cn("relative w-full max-w-2xl", className)} {...props}>
        <div className="relative">
          <Input
            type="text"
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyPress={handleKeyPress}
            onFocus={() => setShowSuggestions(suggestions.length > 0)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
            className="bg-card/50 border-border backdrop-blur-sm pr-12 py-3 text-base placeholder:text-muted-foreground focus:border-neon-purple focus:glow-neon"
          />
          <Button
            onClick={onSearch}
            variant="hero"
            size="sm"
            className="absolute right-1 top-1 bottom-1 px-3"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
        
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-deep z-50 max-h-60 overflow-y-auto">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className="w-full px-4 py-2 text-left hover:bg-secondary transition-colors text-foreground first:rounded-t-lg last:rounded-b-lg"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }
);

SearchBar.displayName = "SearchBar";