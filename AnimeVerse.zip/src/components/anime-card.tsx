import React from 'react';
import { Star, Calendar, Tv } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Anime } from '@/data/animeData';
import { cn } from '@/lib/utils';

interface AnimeCardProps {
  anime: Anime;
  onClick: () => void;
  className?: string;
}

export const AnimeCard: React.FC<AnimeCardProps> = ({ anime, onClick, className }) => {
  return (
    <Card 
      className={cn(
        "group cursor-pointer overflow-hidden bg-gradient-card border-neon-purple/30 hover:border-neon-purple transition-all duration-300 hover:scale-105 hover:glow-neon shadow-deep",
        className
      )}
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img
          src={anime.image}
          alt={anime.title}
          className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-background/80 text-foreground">
            <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
            {anime.rating}
          </Badge>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-4">
          <h3 className="font-anime font-bold text-lg text-foreground mb-1 line-clamp-1">
            {anime.title}
          </h3>
        </div>
      </div>
      
      <CardContent className="p-4">
        <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
          {anime.synopsis}
        </p>
        
        <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {anime.releaseYear}
          </div>
          <div className="flex items-center gap-1">
            <Tv className="w-3 h-3" />
            {anime.episodes} eps
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1">
          {anime.genres.slice(0, 3).map((genre) => (
            <Badge key={genre} variant="outline" className="text-xs border-neon-cyan/30 text-neon-cyan">
              {genre}
            </Badge>
          ))}
          {anime.genres.length > 3 && (
            <Badge variant="outline" className="text-xs border-neon-cyan/30 text-neon-cyan">
              +{anime.genres.length - 3}
            </Badge>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button variant="anime" size="sm" className="w-full">
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
};